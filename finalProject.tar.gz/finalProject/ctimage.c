#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <math.h> 
 
const int SCAN_DIM = 1024; 
const int AREA = 1048576; 
const int MAX_INTENSITY = 4096; 
const float DEGTORAD = 0.01745f; 
const float RADTODEG = 57.29577f; 
const int BYTES_PER_PIXEL = 2; 
const float D = 5.0f; 
 
int main(int argc, char **argv) 
{ 
	int i, j, x, y, z, start, RANGE, scan_num, OUT_DIM, base, data_u, data_v, 
 	io = 0; 
 	float intensity; 
 	char *filepath; 
 	FILE *in_file; 
 
	// scan data matrix 
 	short int ***scan_data, *scan_mem; 
 
	// result matrix 
 	float ***intensity_data, *intensity_mem; 
 	float s, t, d, u, v, w, beta; 
 
 	// Args: starting file path, start #, range, out dimension, I/O boolean 
 	if (argc == 6) { 
 		filepath = argv[1]; 
 		start = atoi(argv[2]); 
 		RANGE = atoi(argv[3]); 
 		OUT_DIM = atoi(argv[4]); 
 		io = atoi(argv[5]); 
 	} 
 	else { 
 		printf("Argument error: Need path, start, range, and output resolution\n"); 
 		exit(1); 
 	} 
 
 	// Set up scan data matrix 
 	scan_mem = (short int*)malloc(RANGE*AREA*sizeof(short int)); 
 	scan_data = (short int***)malloc(RANGE*sizeof(short int**)); 
 
 	for (i = 0; i < RANGE; i++) { 
 		scan_data[i] = (short int**)malloc(SCAN_DIM*sizeof(short int*)); 
 	} 
 
 	// make memory contiguous 
 	for (i = 0; i < RANGE; i++) { 
 		for (j = 0; j < SCAN_DIM; j++) { 
 		scan_data[i][j] = &scan_mem[i*RANGE*SCAN_DIM+j*SCAN_DIM];
 		} 
 	} 
 
 	// Set up intensity matrix 
 	intensity_mem = (float*)malloc(OUT_DIM*OUT_DIM*OUT_DIM*sizeof(float)); 
 	intensity_data = (float***)malloc(OUT_DIM*sizeof(float**)); 
 
 	for (i = 0; i < OUT_DIM; i++) { 
 		intensity_data[i] = (float**)malloc(OUT_DIM*sizeof(float*)); 
 	} 
 
 	// make memory contiguous 
 	for (i = 0; i < OUT_DIM; i++) { 
 		for (j = 0; j < OUT_DIM; j++) { 
 			intensity_data[i][j] = &intensity_mem[i*OUT_DIM*OUT_DIM+j*OUT_DIM]; 
 		} 
 	} 
 
 	// read in all scans from disk 
 	for (scan_num = start; scan_num < start+RANGE; scan_num++) { 
 
 		in_file = fopen(filepath, "rb"); 
 		
		if (!in_file) { 
 			perror("File Error"); 
 		} 
 
 		base = scan_num - start; 
 
 		// load scans to memory 
 		fread(scan_data[base][0], BYTES_PER_PIXEL, AREA, in_file); 
 		fclose(in_file); 
 	} 
 
 	// Feldkamp algorithm 
	 for(x = 0; x < OUT_DIM; x++) { 
 		for (y = 0; y < OUT_DIM; y++) { 
 			for (z = 0; z < OUT_DIM; z++) { 
 				intensity = 0.0f; 
 					
				for (scan_num = start; scan_num < start+RANGE; scan_num++) { 
					beta = scan_num*1.5f*DEGTORAD; 
					s = x * cosf(beta) + y * sinf(beta); 
					t = -x * sinf(beta) + y * cosf(beta); 
					d = D / (D - s); 
					u = t * d; 
 					v = z * d; 
 					w = powf(d, 2); 
 					data_u = (int)u; 
 					data_v = (int)v; 
 
 					if ((data_u >= 0 && data_u < OUT_DIM) && 
 					(data_v >= 0 && data_v < OUT_DIM)) { 
 						intensity += w * scan_data[scan_num][data_u][data_v]; 
 					} 
 				} 
 				intensity_data[x][y][z] = intensity; 
 			} 
 		} 
 	}
 	
	if (io) { 
 		for(x = 0; x < OUT_DIM; x++) { 
 			for (y = 0; y < OUT_DIM; y++) { 
 				for (z = 0; z < OUT_DIM; z++) { 
 					printf("%f\n", intensity_data[x][y][z]); 
 				} 
 			} 
 		} 
 	} 
 
 	// deallocate memory 
 	free(scan_mem); 
 	free(scan_data); 
 	free(intensity_mem); 
 	free(intensity_data); 
 
 	return 0;
} 
